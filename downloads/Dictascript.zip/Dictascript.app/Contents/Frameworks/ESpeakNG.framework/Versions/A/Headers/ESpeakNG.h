#import <ESpeakNG/espeak_ng.h>
#import <ESpeakNG/speak_lib.h>
#import <ESpeakNG/encoding.h>
#import <ESpeakNG/espeak-ng/espeak_ng.h>
#import <ESpeakNG/espeak-ng/speak_lib.h>
#import <ESpeakNG/espeak-ng/encoding.h>
